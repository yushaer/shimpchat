import React from 'react';
import logo from './logo.svg';
import './App.css';
import Login from './Login/Login';
import Navbar from './Components/Navbar/Navbar';

function App() {
  return (
    <React.Fragment>
      <Navbar/>
   
    <div className="container">
     
 
    </div>
    </React.Fragment>
  );
}

export default App;
