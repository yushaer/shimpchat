import React from 'react';
class Message extends React.Component{
    constructor(props){
        super(props);
    }
    render(){
        return(
            <div class="box-gray z-depth-4">
            <p>{this.props.message}</p>
            <div>
                <strong>{this.props.name}</strong><br></br>({this.props.date})

            </div>
                            
        
           
          
            </div>
        )
    }
}
export default Message;