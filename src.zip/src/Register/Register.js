import React from 'react';
import M from 'materialize-css';
import firebase from '../Components/Firebase';
import { Redirect } from 'react-router';
import { connect } from 'react-redux';
import {setUser,login ,set_login_status } from '../Actions/'
class Login extends React.Component{
    constructor(props){
        super(props);
        this.signUp=this.signUp.bind(this);
        this.state={loggedIn:false,"error":""}

    }
    componentDidMount() {
        this.props.dispatch(set_login_status());
        const that=this;
        firebase.auth().onAuthStateChanged(function(user) {
          
            if (user) {
              // User is signed in.
             
              var user = firebase.auth().currentUser;
              var name=document.getElementById("name").value;
           

          
            } else {
              // No user is signed in.
            }
          });
     
    }
    signUp(e){
        e.preventDefault();
        const  that = this;
        var email=document.getElementById("email").value;
        var password=document.getElementById("password").value;
        firebase.auth().createUserWithEmailAndPassword(email, password).then(function () {
            firebase.auth().signInWithEmailAndPassword(email, password).then(function () {
              var user = firebase.auth().currentUser;
              var name=document.getElementById("name").value;

                user.updateProfile({
                    displayName: name
                  }).then(function() {
                  
                      
                     
                    
                
                    // window.location.href("localhost:3000/")
                    // Update successful.
                  }).catch(function(error) {
                    // An error happened.
                  })
               
            }).catch(function(error) {
                // Handle Errors here.
                var errorCode = error.code;
                var errorMessage = error.message;
                // ...
                console.log(errorMessage)
                that.state.error=errorMessage;
                that.setState(that.state);
                console.log(this.state.error);
              });
              
            
        }).catch(function(error) {
            // Handle Errors here.
            var errorCode = error.code;
            var errorMessage = error.message;
            console.log(errorMessage)
            that.state.error=errorMessage;
            that.setState(that.state);
            console.log(that.state.error);
            // ...
          });
       
    }

    render(){
        console.log(this.state)
        const btn_style={
            "backgroundColor":"#fff",
            color:"#212121"
        }
        if(this.state.loggedIn){
            console.log("logged in")
            return (<Redirect to="/shimpchat" />);
        }else{
            return(
            <div class="container">
                <div class="card">
                                <h1 className="header center black-text">Register</h1>
                                <hr></hr>
                                <div className="card-content red-text">
                                    <p id="error">{this.state.error}</p>
                                <form>

                                <div className="row">
                                        <div className="input-field col s12">
                                        <input id="name" type="text" className="validate"/>
                                        <label for="name">name</label>
                                        </div>
                                    </div>
                                    <div className="row">
                                        <div className="input-field col s12">
                                        <input id="email" type="email" className="validate"/>
                                        <label for="email">Email</label>
                                        </div>
                                    </div>
                                    <div className="row">
                                        <div className="input-field col s12">
                                        <input id="password" type="password" className="validate"/>
                                        <label for="password">password</label>
                                        </div>
                                    </div>
                                    <div className="center">
                                        <div className="input-field col s12">
                                            <button className="btn waves-effect " style={btn_style} type ="submit"  onClick={this.signUp} name="action">
                                            Register
                                            </button>
                                                    
                                        
                                        </div>
                                    </div>
                                </form>
                                </div>
                            </div>
                        </div>

            )
            }
    }
    
}
function mapStateToProps(state) {
    return {
      user: state.user,
      logged_in:state.logged_in
      
    };
  }

export default connect(mapStateToProps)(Login)
